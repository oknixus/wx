<?php

/**
 * Class test
 * @author John Doe
 */
class test
{
    public function __construct($options)
    {
        // code
    }
}

